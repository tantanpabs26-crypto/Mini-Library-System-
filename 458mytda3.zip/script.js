// --- DATA (Arrays = DSA Concept) ---
let books = JSON.parse(localStorage.getItem('lib_books') || '[]');
let borrowers = JSON.parse(localStorage.getItem('lib_borrowers') || '[]');
let transactions = JSON.parse(localStorage.getItem('lib_trans') || '[]');
let queue = JSON.parse(localStorage.getItem('lib_queue') || '[]'); // Queue
let categories = JSON.parse(localStorage.getItem('lib_cats') || '["History and Geography","Computers, Information and General Reference","Religion","Adventure","Fiction","Science"]');
let users = JSON.parse(localStorage.getItem('lib_users') || '[{"name":"admin","role":"Admin"}]');
let logs = JSON.parse(localStorage.getItem('lib_logs') || '[]');
let selectedIndex = -1;
let sortAsc = true;

if (books.length === 0) {
  books = [
    { acc: 'A001', title: 'Life of Jude', desc: 'The Adventure of Jude', author: 'Unknown', date: '2021-02-26', pub: 'Unknown', cat: 'History and Geography', type: 'Non-Fiction', price: 0, status: 'Available' },
    { acc: 'A002', title: 'The Brain of Jude', desc: 'No Brain Programmer', author: 'Unknown', date: '2021-02-26', pub: 'Unknown', cat: 'Computers, Information and General Reference', type: 'Unknown', price: 0, status: 'Available' },
    { acc: 'A003', title: 'The Love of Jude', desc: 'The loving Angel Jude', author: 'Unknown', date: '2021-02-26', pub: 'Unknown', cat: 'Religion', type: 'Non-Fiction', price: 0, status: 'Available' },
    { acc: 'A004', title: 'Noli Me Tangere', desc: 'Novel by Jose Rizal', author: 'Jose Rizal', date: '1887-01-01', pub: 'Berlin', cat: 'Fiction', type: 'Fiction', price: 250, status: 'Available' },
    { acc: 'A005', title: 'El Filibusterismo', desc: 'Sequel to Noli Me Tangere', author: 'Jose Rizal', date: '1891-01-01', pub: 'Ghent', cat: 'Fiction', type: 'Fiction', price: 280, status: 'Available' },
    { acc: 'A006', title: 'Harry Potter and the Sorcerer\'s Stone', desc: 'A boy discovers he is a wizard', author: 'J.K. Rowling', date: '1997-06-26', pub: 'Bloomsbury', cat: 'Adventure', type: 'Fiction', price: 450, status: 'Available' },
    { acc: 'A007', title: 'The Hunger Games', desc: 'Katniss fights for survival', author: 'Suzanne Collins', date: '2008-09-14', pub: 'Scholastic', cat: 'Adventure', type: 'Fiction', price: 380, status: 'Available' },
    { acc: 'A008', title: 'Introduction to Algorithms', desc: 'Data Structures and Algorithms', author: 'Thomas Cormen', date: '2009-07-31', pub: 'MIT Press', cat: 'Computers, Information and General Reference', type: 'Non-Fiction', price: 1200, status: 'Available' },
    { acc: 'A009', title: 'Clean Code', desc: 'A Handbook of Agile Software Craftsmanship', author: 'Robert Martin', date: '2008-08-01', pub: 'Prentice Hall', cat: 'Computers, Information and General Reference', type: 'Non-Fiction', price: 950, status: 'Available' },
    { acc: 'A010', title: 'The Alchemist', desc: 'A shepherd boy follows his dream', author: 'Paulo Coelho', date: '1988-01-01', pub: 'HarperCollins', cat: 'Fiction', type: 'Fiction', price: 320, status: 'Available' },
    { acc: 'A011', title: 'Atomic Habits', desc: 'Tiny changes, remarkable results', author: 'James Clear', date: '2018-10-16', pub: 'Avery', cat: 'Science', type: 'Non-Fiction', price: 550, status: 'Available' },
    { acc: 'A012', title: 'Sapiens', desc: 'A Brief History of Humankind', author: 'Yuval Noah Harari', date: '2011-01-01', pub: 'Harper', cat: 'History and Geography', type: 'Non-Fiction', price: 600, status: 'Available' },
    { acc: 'A013', title: 'Math for Beginners', desc: 'Basic Algebra and Geometry', author: 'Juan Dela Cruz', date: '2020-05-10', pub: 'DepEd', cat: 'Science', type: 'Non-Fiction', price: 150, status: 'Available' },
    { acc: 'A014', title: 'Philippine History', desc: 'From Pre-colonial to Modern', author: 'Zaide', date: '2015-03-15', pub: 'National Bookstore', cat: 'History and Geography', type: 'Non-Fiction', price: 400, status: 'Available' },
    { acc: 'A015', title: 'The Bible', desc: 'Old and New Testament', author: 'Various', date: '2000-01-01', pub: 'Philippine Bible Society', cat: 'Religion', type: 'Non-Fiction', price: 500, status: 'Available' },
    { acc: 'A016', title: 'Percy Jackson and the Lightning Thief', desc: 'A boy discovers he is a demigod', author: 'Rick Riordan', date: '2005-06-28', pub: 'Disney', cat: 'Adventure', type: 'Fiction', price: 420, status: 'Available' },
    { acc: 'A017', title: 'Diary of a Wimpy Kid', desc: 'Funny school diary', author: 'Jeff Kinney', date: '2007-04-01', pub: 'Amulet Books', cat: 'Fiction', type: 'Fiction', price: 300, status: 'Available' },
    { acc: 'A018', title: 'Programming in Java', desc: 'Learn Java for beginners', author: 'Maria Santos', date: '2022-08-20', pub: 'Tech Press', cat: 'Computers, Information and General Reference', type: 'Non-Fiction', price: 700, status: 'Available' },
    { acc: 'A019', title: 'General Science', desc: 'Physics, Chemistry, Biology', author: 'Dr. Reyes', date: '2019-11-11', pub: 'Science Press', cat: 'Science', type: 'Non-Fiction', price: 350, status: 'Available' },
    { acc: 'A020', title: 'Florante at Laura', desc: 'Classic Filipino epic poem', author: 'Francisco Balagtas', date: '1838-01-01', pub: 'National', cat: 'Fiction', type: 'Fiction', price: 200, status: 'Available' },
  ];
  saveAll();
}
function saveAll() {
  localStorage.setItem('lib_books', JSON.stringify(books));
  localStorage.setItem('lib_borrowers', JSON.stringify(borrowers));
  localStorage.setItem('lib_trans', JSON.stringify(transactions));
  localStorage.setItem('lib_queue', JSON.stringify(queue));
  localStorage.setItem('lib_cats', JSON.stringify(categories));
  localStorage.setItem('lib_users', JSON.stringify(users));
  localStorage.setItem('lib_logs', JSON.stringify(logs));
}
function addLog(msg) { logs.unshift(new Date().toLocaleString() + ' - ' + msg); saveAll(); renderLogs(); }

function renderAll() { renderBooks(); renderBorrowers(); renderCategories(); renderUsers(); renderTrans(); renderQueue(); renderStats(); renderReport(); renderLogs(); renderTransSelect(); }

function renderStats() {
  document.getElementById('totalBooks').textContent = books.length;
  document.getElementById('totalBorrowed').textContent = books.filter(b => b.status === 'Borrowed').length;
  document.getElementById('totalAvailable').textContent = books.filter(b => b.status !== 'Borrowed').length;
  document.getElementById('totalBorrowers').textContent = borrowers.length;
  document.getElementById('totalQueue').textContent = queue.length;
}

// --- BOOKS CRUD + Searching + Sorting ---
function renderBooks() {
  const q = (document.getElementById('searchBook').value || '').toLowerCase();
  const tbody = document.getElementById('bookTable'); tbody.innerHTML = '';
  books.forEach((b, i) => {
    if (q && !(b.title + b.author + b.acc + b.cat).toLowerCase().includes(q)) return;
    const tr = document.createElement('tr');
    if (i === selectedIndex) tr.className = 'selected';
    tr.innerHTML = `<td>${b.acc}</td><td>${b.title}</td><td>${b.desc}</td><td>${b.author}</td><td>${b.date}</td><td>${b.pub}</td><td>${b.cat}</td><td>${b.type}</td><td>${b.price}</td><td><span class="badge ${b.status === 'Borrowed' ? 'borrowed' : ''}">${b.status}</span></td>`;
    tr.onclick = () => { selectedIndex = i; fillForm(b); renderBooks(); };
    tbody.appendChild(tr);
  });
  renderStats();
}
function fillForm(b) {
  accNo.value = b.acc; title.value = b.title; desc.value = b.desc; author.value = b.author; datePub.value = b.date; publisher.value = b.pub; category.value = b.cat; type.value = b.type; price.value = b.price;
}
function getForm() { return { acc: accNo.value.trim(), title: title.value.trim(), desc: desc.value.trim(), author: author.value.trim() || 'Unknown', date: datePub.value, pub: publisher.value.trim() || 'Unknown', cat: category.value, type: type.value, price: price.value || 0, status: 'Available' }; }
function saveBook() {
  const b = getForm(); if (!b.acc || !b.title) return alert('Accession No. and Title are required!');
  if (books.find(x => x.acc === b.acc)) return alert('Accession No. already exists!');
  books.push(b); addLog('Added book: ' + b.title); saveAll(); renderAll(); clearForm();
}
function updateBook() {
  if (selectedIndex < 0) return alert('Select a book from table first!');
  const b = getForm(); b.status = books[selectedIndex].status; books[selectedIndex] = b; addLog('Updated book: ' + b.title); saveAll(); renderAll();
}
function deleteBook() {
  if (selectedIndex < 0) return alert('Select a book first!');
  if (!confirm('Delete ' + books[selectedIndex].title + '?')) return;
  addLog('Deleted book: ' + books[selectedIndex].title); books.splice(selectedIndex, 1); selectedIndex = -1; saveAll(); renderAll(); clearForm();
}
function clearForm() { selectedIndex = -1; ['accNo', 'title', 'desc', 'author', 'publisher', 'price'].forEach(id => document.getElementById(id).value = ''); renderBooks(); }
function sortBooks() { sortAsc = !sortAsc; books.sort((a, b) => sortAsc ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title)); saveAll(); renderBooks(); }

// --- TRANSACTION ---
function renderTransSelect() { transBook.innerHTML = books.map((b, i) => `<option value="${i}">${b.title} (${b.acc}) - ${b.status}</option>`).join(''); }
function renderTrans() { transTable.innerHTML = transactions.map(t => `<tr><td>${t.date}</td><td>${t.book}</td><td>${t.borrower}</td><td>${t.action}</td></tr>`).join(''); }
function renderQueue() { queueList.innerHTML = queue.map((q, i) => `<li>${i + 1}. ${q.borrower} waiting for <b>${q.book}</b> <button onclick="removeQueue(${i})">Remove</button></li>`).join('') || '<li>No one in queue</li>'; }
function removeQueue(i) { queue.splice(i, 1); saveAll(); renderAll(); }
function borrowBook() {
  const idx = +transBook.value; const name = transBorrower.value.trim(); if (!name) return alert('Enter borrower name');
  const book = books[idx];
  if (book.status === 'Borrowed') { alert('Book is borrowed! Join queue instead.'); return; }
  book.status = 'Borrowed'; transactions.unshift({ date: new Date().toLocaleString(), book: book.title, borrower: name, action: 'Borrowed' }); addLog(name + ' borrowed ' + book.title); saveAll(); renderAll();
}
function returnBook() {
  const idx = +transBook.value; const name = transBorrower.value.trim() || 'Unknown'; const book = books[idx];
  book.status = 'Available'; transactions.unshift({ date: new Date().toLocaleString(), book: book.title, borrower: name, action: 'Returned' }); addLog(name + ' returned ' + book.title);
  const qi = queue.findIndex(q => q.book === book.title);
  if (qi >= 0) { const next = queue.splice(qi, 1)[0]; alert('Next in queue: ' + next.borrower + ' can now borrow ' + book.title); }
  saveAll(); renderAll();
}
function joinQueue() {
  const idx = +transBook.value; const name = transBorrower.value.trim(); if (!name) return alert('Enter name');
  queue.push({ book: books[idx].title, borrower: name }); addLog(name + ' joined queue for ' + books[idx].title); saveAll(); renderAll();
}

// --- BORROWER / CATEGORY / USER ---
function renderBorrowers() { borrowerTable.innerHTML = borrowers.map((b, i) => `<tr><td>${b.name}</td><td>${b.id}</td><td>${b.course}</td><td>${b.contact}</td><td><button onclick="borrowers.splice(${i},1);saveAll();renderAll()">Delete</button></td></tr>`).join(''); }
function addBorrower() { if (!bName.value.trim()) return alert('Enter name'); borrowers.push({ name: bName.value, id: bId.value, course: bCourse.value, contact: bContact.value }); addLog('Added borrower: ' + bName.value); saveAll(); renderAll(); clearBorrower(); }
function clearBorrower() { ['bName', 'bId', 'bCourse', 'bContact'].forEach(id => document.getElementById(id).value = ''); }

function renderCategories() {
  category.innerHTML = categories.map(c => `<option>${c}</option>`).join('');
  catList.innerHTML = categories.map((c, i) => `<span>${c} <button onclick="categories.splice(${i},1);saveAll();renderAll()">✕</button></span>`).join('');
}
function addCategory() { if (!newCat.value.trim()) return; categories.push(newCat.value.trim()); newCat.value = ''; saveAll(); renderAll(); }

function renderUsers() { userTable.innerHTML = users.map(u => `<tr><td>${u.name}</td><td>${u.role}</td></tr>`).join(''); }
function addUser() { if (!uName.value.trim()) return; users.push({ name: uName.value, role: uRole.value }); uName.value = ''; saveAll(); renderAll(); }

function renderReport() {
  let byCat = {}; books.forEach(b => byCat[b.cat] = (byCat[b.cat] || 0) + 1);
  reportArea.innerHTML = `<p>Total Books: <b>${books.length}</b> | Borrowed: <b>${books.filter(b => b.status === 'Borrowed').length}</b></p><h4>By Category</h4><ul>${Object.entries(byCat).map(([k, v]) => `<li>${k}: ${v}</li>`).join('')}</ul>`;
}
function renderLogs() { logList.innerHTML = logs.map(l => `<li>${l}</li>`).join('') || '<li>No logs yet</li>'; }
function clearLogs() { logs = []; saveAll(); renderLogs(); }

// --- TABS ---
document.querySelectorAll('#nav button').forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll('#nav button').forEach(b => b.classList.remove('active')); btn.classList.add('active');
    document.querySelectorAll('[id^="tab-"]').forEach(d => d.classList.add('hidden'));
    document.getElementById('tab-' + btn.dataset.tab).classList.remove('hidden');
  };
});

renderAll();